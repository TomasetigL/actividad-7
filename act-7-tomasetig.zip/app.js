const express = require('express');
const bodyParser = require('body-parser');
const alumnosRoutes = require('./routes/alumnosRoutes');

const app = express();
const PORT = 2023;

app.use(bodyParser.json());

app.use('/', alumnosRoutes);

app.listen(PORT, () => {
  console.log(`Servidor Express escuchando en el puerto ${PORT}`);
});
