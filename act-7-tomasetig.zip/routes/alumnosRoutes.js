const express = require('express');
const alumnosController = require('../controllers/alumnosController');

const router = express.Router();

router.get('/', (req, res) => {
  res.send('¡Bienvenido! <a href="/alumnos">Lista de Alumnos</a>');
});
router.get('/alumnos', alumnosController.getAlumnos);
router.get('/alumnos/:legajo', alumnosController.getAlumno);

router.post('/alumnos', alumnosController.addAlumno);
router.put('/alumnos/:legajo', alumnosController.updateAlumno);
router.delete('/alumnos/:legajo', alumnosController.deleteAlumno);


module.exports = router;
