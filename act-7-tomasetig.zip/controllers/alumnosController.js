const alumnosService = require('../services/alumnosService');

const getAlumnos = (req, res) => {
    const alumnos = alumnosService.getAlumnos();
    let html = '<ul>';
    alumnos.forEach((alumno) => {
      html += `
        <li>
          <a href="/alumnos/${alumno.legajo}">
            ${alumno.nombre} ${alumno.apellido}
          </a>
        </li>
      `;
    });
    html += '</ul>';
    res.send(html);
  };
  
  const getAlumno = (req, res) => {
    const { legajo } = req.params;
    const alumnos = alumnosService.getAlumnos();
    const alumno = alumnos.find((alumno) => alumno.legajo === legajo);
    if (alumno) {
      let html = `
        <h1>${alumno.nombre} ${alumno.apellido}</h1>
        <p>Legajo: ${alumno.legajo}</p>
        <p>Año de inscripción: ${alumno.año}</p>
      `;
      res.send(html);
    } else {
      res.sendStatus(404);
    }
  };

const addAlumno = (req, res) => {
  const { legajo, nombre, apellido, año } = req.body;
  const alumnos = alumnosService.getAlumnos();
  alumnos.push({ legajo, nombre, apellido, año });
  alumnosService.saveAlumnos(alumnos);
  res.sendStatus(201);
};

const updateAlumno = (req, res) => {
  const { legajo } = req.params;
  const { nombre, apellido, año } = req.body;
  const alumnos = alumnosService.getAlumnos();
  const index = alumnos.findIndex((alumno) => alumno.legajo === legajo);
  if (index !== -1) {
    alumnos[index] = { legajo, nombre, apellido, año };
    alumnosService.saveAlumnos(alumnos);
    res.sendStatus(200);
  } else {
    res.sendStatus(404);
  }
};

const deleteAlumno = (req, res) => {
  const { legajo } = req.params;
  const alumnos = alumnosService.getAlumnos();
  const index = alumnos.findIndex((alumno) => alumno.legajo === legajo);
  if (index !== -1) {
    alumnos.splice(index, 1);
    alumnosService.saveAlumnos(alumnos);
    res.sendStatus(204);
  } else {
    res.sendStatus(404);
  }
};

module.exports = {
  getAlumnos,
  addAlumno,
  updateAlumno,
  deleteAlumno,
  getAlumno
};
