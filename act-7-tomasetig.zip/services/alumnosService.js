const fs = require('fs');
const path = require('path');

const alumnosFilePath = path.join(__dirname, '../data/alumnos.json');

const getAlumnos = () => {
  const alumnosData = fs.readFileSync(alumnosFilePath, 'utf8');
  return JSON.parse(alumnosData);
};

const saveAlumnos = (alumnos) => {
  fs.writeFileSync(alumnosFilePath, JSON.stringify(alumnos, null, 2), 'utf8');
};

module.exports = {
  getAlumnos,
  saveAlumnos,
};
